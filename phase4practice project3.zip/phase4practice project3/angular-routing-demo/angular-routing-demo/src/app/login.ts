export class Login {
    constructor(public email:string,public pass:string){}
}
