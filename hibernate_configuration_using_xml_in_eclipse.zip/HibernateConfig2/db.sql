CREATE DATABASE ecommerce;
USE ecommerce;
CREATE TABLE eproduct (ID bigint primary key auto_increment, name varchar(100), price decimal(10,2), date_added timestamp default now()); 
INSERT INTO eproduct (name,price) VALUES ('HP Laptop ABC', 12000);
INSERT INTO eproduct (name,price) VALUES ('Acer Laptop ABC', 14000);
INSERT INTO eproduct (name,price) VALUES ('Lenovo Laptop ABC', 12000); 
SELECT * from eproduct;